package id.sch.smkn14kabupatentangerang.cbtbeta

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JsResult
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/**
 * CBT SMKN 14 EXAMBROWSER (0.2.2 BETA)
 *
 * Aplikasi sekolah yang langsung membuka portal CBT di dalam WebView.
 * Tidak ada address bar, tombol maju/mundur browser, menu browser, atau riwayat.
 * Tidak ada kiosk mode, lock task, PIN proktor, FLAG_SECURE, kunci tombol Back,
 * screen pinning, maupun sistem anti-exit.
 *
 * Pengaturan yang bisa diubah administrator (alamat portal, identitas aplikasi)
 * ada di gradle.properties dan dibaca lewat BuildConfig.
 */
class MainActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var splashPanel: View
    private lateinit var errorPanel: View
    private lateinit var errorMessage: TextView
    private lateinit var errorDetail: TextView

    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private var pendingDownload: PendingDownload? = null

    // true bila pemuatan halaman utama terakhir gagal (halaman error sedang tampil)
    private var loadFailed = false
    private var failedUrl: String? = null

    private val portalHost: String? = Uri.parse(BuildConfig.PORTAL_URL).host

    private class PendingDownload(
        val url: String,
        val userAgent: String?,
        val contentDisposition: String?,
        val mimeType: String?
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)
        splashPanel = findViewById(R.id.splashPanel)
        errorPanel = findViewById(R.id.errorPanel)
        errorMessage = findViewById(R.id.errorMessage)
        errorDetail = findViewById(R.id.errorDetail)

        findViewById<Button>(R.id.retryButton).setOnClickListener { reloadPage() }

        configureWebView()
        loadPortal()
    }

    // ------------------------------------------------------------------
    // Konfigurasi WebView
    // ------------------------------------------------------------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadsImagesAutomatically = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        // Viewport mengikuti layar HP; pinch-zoom tetap bisa, tombol zoom bawaan disembunyikan.
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false

        // Pengaturan aman: tanpa akses file lokal, tanpa jendela popup, tanpa lokasi.
        // Mixed content dan HTTP cleartext TIDAK diaktifkan (memakai bawaan Android yang aman).
        settings.allowFileAccess = false
        settings.javaScriptCanOpenWindowsAutomatically = false
        settings.setSupportMultipleWindows(false)
        settings.setGeolocationEnabled(false)

        // Identitas aplikasi pada User-Agent (dikirim di semua permintaan).
        if (BuildConfig.APP_UA_TOKEN.isNotBlank()) {
            settings.userAgentString = settings.userAgentString + " " + BuildConfig.APP_UA_TOKEN
        }

        CookieManager.getInstance().setAcceptCookie(true)

        webView.webViewClient = createWebViewClient()
        webView.webChromeClient = createWebChromeClient()
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            startDownload(PendingDownload(url, userAgent, contentDisposition, mimeType))
        }
    }

    private fun createWebViewClient(): WebViewClient = object : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            return handleNavigation(
                view,
                request.url,
                request.isForMainFrame,
                request.method,
                request.requestHeaders
            )
        }

        @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            return handleNavigation(view, Uri.parse(url), true, "GET", null)
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
            loadFailed = false
            errorPanel.visibility = View.GONE
            webView.visibility = View.VISIBLE
            progressBar.progress = 0
            progressBar.visibility = View.VISIBLE
        }

        override fun onPageFinished(view: WebView, url: String?) {
            super.onPageFinished(view, url)
            progressBar.visibility = View.INVISIBLE
            if (!loadFailed) {
                splashPanel.visibility = View.GONE
            }
            CookieManager.getInstance().flush()
        }

        override fun onReceivedError(
            view: WebView,
            request: WebResourceRequest,
            error: WebResourceError
        ) {
            super.onReceivedError(view, request, error)
            if (request.isForMainFrame) {
                showError(
                    request.url.toString(),
                    messageForError(error.errorCode),
                    "${error.description} (${error.errorCode})"
                )
            }
        }

        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
            // Keamanan koneksi tidak dilonggarkan: sertifikat bermasalah selalu ditolak.
            handler.cancel()
            if (isPortalHost(Uri.parse(error.url))) {
                showError(error.url, getString(R.string.error_ssl), "SSL error ${error.primaryError}")
            }
        }
    }

    private fun createWebChromeClient(): WebChromeClient = object : WebChromeClient() {

        override fun onProgressChanged(view: WebView, newProgress: Int) {
            progressBar.progress = newProgress
            if (newProgress >= 100) {
                progressBar.visibility = View.INVISIBLE
            }
        }

        override fun onJsAlert(
            view: WebView,
            url: String?,
            message: String?,
            result: JsResult
        ): Boolean {
            if (isFinishing) {
                result.cancel()
                return true
            }
            AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.dialog_info_title)
                .setMessage(message)
                .setPositiveButton(R.string.action_ok) { _, _ -> result.confirm() }
                .setOnCancelListener { result.cancel() }
                .show()
            return true
        }

        override fun onJsConfirm(
            view: WebView,
            url: String?,
            message: String?,
            result: JsResult
        ): Boolean {
            if (isFinishing) {
                result.cancel()
                return true
            }
            AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.dialog_confirm_title)
                .setMessage(message)
                .setPositiveButton(R.string.action_yes) { _, _ -> result.confirm() }
                .setNegativeButton(R.string.action_cancel) { _, _ -> result.cancel() }
                .setOnCancelListener { result.cancel() }
                .show()
            return true
        }

        override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
        ): Boolean {
            uploadCallback?.onReceiveValue(null)
            uploadCallback = filePathCallback
            return try {
                val intent = fileChooserParams?.createIntent()
                    ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                startActivityForResult(intent, REQUEST_FILE_CHOOSER)
                true
            } catch (e: ActivityNotFoundException) {
                uploadCallback?.onReceiveValue(null)
                uploadCallback = null
                toast(R.string.toast_no_file_picker)
                false
            }
        }
    }

    // ------------------------------------------------------------------
    // Navigasi dan identitas aplikasi
    // ------------------------------------------------------------------

    /**
     * Mengembalikan true bila navigasi sudah ditangani aplikasi.
     * - http/https biasa dimuat WebView. Untuk halaman utama di host portal (GET),
     *   header identitas aplikasi ditambahkan lebih dulu; header TIDAK dikirim ke situs lain.
     * - Skema aman (mailto, tel, sms, geo) dibuka lewat aplikasi lain.
     * - Skema lain (file, content, intent, dll.) ditolak.
     */
    private fun handleNavigation(
        view: WebView,
        uri: Uri,
        isMainFrame: Boolean,
        method: String?,
        requestHeaders: Map<String, String>?
    ): Boolean {
        return when (uri.scheme?.lowercase(Locale.ROOT)) {
            "http", "https" -> {
                val onPortal = isPortalHost(uri)
                when {
                    // Halaman utama di host portal selalu lewat HTTPS.
                    isMainFrame && onPortal && uri.scheme.equals("http", ignoreCase = true) -> {
                        view.loadUrl(
                            uri.buildUpon().scheme("https").build().toString(),
                            identityHeaders()
                        )
                        true
                    }
                    isMainFrame && onPortal &&
                        method.equals("GET", ignoreCase = true) &&
                        identityHeaders().isNotEmpty() &&
                        !hasIdentityHeader(requestHeaders) -> {
                        view.loadUrl(uri.toString(), identityHeaders())
                        true
                    }
                    else -> false
                }
            }
            "about", "data", "blob", "javascript" -> false
            "mailto", "tel", "sms", "smsto", "geo" -> {
                openWithOtherApp(uri)
                true
            }
            else -> {
                toast(R.string.toast_link_unsupported)
                true
            }
        }
    }

    private fun isPortalHost(uri: Uri): Boolean {
        val host = uri.host ?: return false
        return host.equals(portalHost, ignoreCase = true)
    }

    private fun identityHeaders(): Map<String, String> {
        return if (BuildConfig.APP_HEADER_NAME.isBlank()) {
            emptyMap()
        } else {
            mapOf(BuildConfig.APP_HEADER_NAME to BuildConfig.APP_HEADER_VALUE)
        }
    }

    private fun hasIdentityHeader(headers: Map<String, String>?): Boolean {
        if (headers == null) return false
        return headers.keys.any { it.equals(BuildConfig.APP_HEADER_NAME, ignoreCase = true) }
    }

    private fun loadUrlWithIdentity(url: String) {
        val headers = if (isPortalHost(Uri.parse(url))) identityHeaders() else emptyMap()
        webView.loadUrl(url, headers)
    }

    private fun loadPortal() {
        splashPanel.visibility = View.VISIBLE
        errorPanel.visibility = View.GONE
        loadUrlWithIdentity(BuildConfig.PORTAL_URL)
    }

    private fun reloadPage() {
        val target = if (loadFailed) failedUrl else webView.url
        if (target.isNullOrBlank() || target == "about:blank") {
            loadPortal()
            return
        }
        errorPanel.visibility = View.GONE
        webView.visibility = View.VISIBLE
        loadFailed = false
        if (isPortalHost(Uri.parse(target))) {
            // Dimuat ulang lewat loadUrl supaya header identitas ikut terkirim.
            loadUrlWithIdentity(target)
        } else {
            webView.reload()
        }
    }

    private fun openWithOtherApp(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            toast(R.string.toast_no_app_for_link)
        }
    }

    // ------------------------------------------------------------------
    // Halaman error
    // ------------------------------------------------------------------

    private fun showError(url: String?, message: String, detail: String) {
        loadFailed = true
        failedUrl = url
        errorMessage.text = message
        errorDetail.text = detail
        progressBar.visibility = View.INVISIBLE
        splashPanel.visibility = View.GONE
        webView.visibility = View.INVISIBLE
        errorPanel.visibility = View.VISIBLE
    }

    private fun messageForError(code: Int): String {
        return when (code) {
            WebViewClient.ERROR_HOST_LOOKUP,
            WebViewClient.ERROR_CONNECT,
            WebViewClient.ERROR_IO,
            WebViewClient.ERROR_TIMEOUT -> getString(R.string.error_network)
            WebViewClient.ERROR_FAILED_SSL_HANDSHAKE -> getString(R.string.error_ssl)
            else -> getString(R.string.error_generic)
        }
    }

    // ------------------------------------------------------------------
    // Unduh file
    // ------------------------------------------------------------------

    private fun startDownload(download: PendingDownload) {
        val scheme = Uri.parse(download.url).scheme?.lowercase(Locale.ROOT)
        if (scheme != "http" && scheme != "https") {
            toast(R.string.toast_download_unsupported)
            return
        }
        // Android 9 ke bawah butuh izin penyimpanan untuk menulis ke folder Downloads.
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            pendingDownload = download
            requestPermissions(
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                REQUEST_STORAGE_PERMISSION
            )
            return
        }
        enqueueDownload(download)
    }

    private fun enqueueDownload(download: PendingDownload) {
        try {
            val uri = Uri.parse(download.url)
            val fileName = URLUtil.guessFileName(
                download.url,
                download.contentDisposition,
                download.mimeType
            )
            val request = DownloadManager.Request(uri)
                .setTitle(fileName)
                .setDescription(getString(R.string.download_description))
                .setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                )
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            if (!download.mimeType.isNullOrBlank()) {
                request.setMimeType(download.mimeType)
            }
            val agent = if (download.userAgent.isNullOrBlank()) {
                webView.settings.userAgentString
            } else {
                download.userAgent
            }
            request.addRequestHeader("User-Agent", agent)
            // Sesi login dibawa supaya file yang butuh login tetap bisa diunduh.
            val cookies = CookieManager.getInstance().getCookie(download.url)
            if (!cookies.isNullOrBlank()) {
                request.addRequestHeader("Cookie", cookies)
            }
            if (isPortalHost(uri) && identityHeaders().isNotEmpty()) {
                request.addRequestHeader(BuildConfig.APP_HEADER_NAME, BuildConfig.APP_HEADER_VALUE)
            }
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            toast(R.string.toast_download_started)
        } catch (e: Exception) {
            toast(R.string.toast_download_failed)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_STORAGE_PERMISSION) {
            val download = pendingDownload
            pendingDownload = null
            if (download != null &&
                grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                enqueueDownload(download)
            } else {
                toast(R.string.toast_storage_permission)
            }
        }
    }

    // ------------------------------------------------------------------
    // Siklus hidup dan tombol Back
    // ------------------------------------------------------------------

    /** Tombol Back normal: mundur di riwayat WebView; bila habis, keluar seperti biasa. */
    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_FILE_CHOOSER) {
            uploadCallback?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            )
            uploadCallback = null
        }
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        uploadCallback?.onReceiveValue(null)
        uploadCallback = null
        if (::webView.isInitialized) {
            webView.stopLoading()
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.destroy()
        }
        super.onDestroy()
    }

    private fun toast(messageRes: Int) {
        Toast.makeText(this, messageRes, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val REQUEST_FILE_CHOOSER = 2407
        const val REQUEST_STORAGE_PERMISSION = 2408
    }
}
